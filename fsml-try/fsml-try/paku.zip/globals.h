#ifndef globalsh
#define globalsh
namespace  ag
{
    const int ZONE_WIDTH         = 512;
    const int ZONE_HEIGHT        = 480;
	const int BORDER_LIMIT       = 20;
	const int COLLISION_LIMIT    = 30;
	const int CHARACTER_DISTANCE = 100;
	const float GAME_SPEED       = 200.0f;

}
#endif